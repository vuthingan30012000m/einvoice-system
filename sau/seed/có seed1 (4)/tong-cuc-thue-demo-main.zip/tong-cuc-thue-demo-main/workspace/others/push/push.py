from modules.MyImport import MyImport
# MyImport.Import()
from modules.MyNow import MyNow
message = "VuVanNghia20206205"
message = MyNow()
from modules.MyGit import MyGit
MyGit.add(message)
MyGit.commit(message)
MyGit.push(message)
from modules.MyClose import MyClose
# MyClose.Terminal()
MyClose.ScrollBar()
MyClose.CloseAll()
MyClose.Target(2)
from modules.MyChrome import MyChrome
# MyChrome()
