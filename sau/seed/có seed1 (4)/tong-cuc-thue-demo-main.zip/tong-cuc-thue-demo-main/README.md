
npm i @nestjs/typeorm typeorm mysql2 class-validator class-transformer consul
npm i @nestjs/swagger
npm i --save @nestjs/axios axios 
npm install @nestjs/swagger
npm install puppeteer

<!-- nest g resource TraCuuMaSoThue --no-spec -->

npm install --save @nestjs-modules/mailer nodemailer
npm install --save-dev @types/nodemailer

https://notiz.dev/blog/send-emails-with-nestjs
https://docs.nestjs.com/techniques/task-scheduling
CREATE DATABASE tong_cuc_thue_demo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


nest g resource CoQuanThue --no-spec

