export class CreateTraCuuMaSoThueDto {}
